return
  {
    keep_comments = true,
    keep_unparsed_tail = true,

    data_struc = nil,
    run = request('run'),

    move_comments = request('move_comments'),
    handlers = request('handlers.interface'),
    align_nodes = request('align_nodes'),
    restruc_nodes = request('restruc_nodes'),
  }
