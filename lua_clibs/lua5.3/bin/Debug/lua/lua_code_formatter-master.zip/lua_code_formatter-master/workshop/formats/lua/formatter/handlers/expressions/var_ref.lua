return
  function(self, node)
    return self:process_node(node.name_part)
  end
