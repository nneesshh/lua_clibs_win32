return
  function(self)
    return self.states[self.position + 1]
  end
