return
  function(self)
    return self.states[self.position]
  end
