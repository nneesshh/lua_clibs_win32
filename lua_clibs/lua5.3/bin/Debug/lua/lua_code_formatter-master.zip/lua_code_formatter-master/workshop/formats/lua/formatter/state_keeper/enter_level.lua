return
  function(self)
    self.position = self.position + 1
  end
