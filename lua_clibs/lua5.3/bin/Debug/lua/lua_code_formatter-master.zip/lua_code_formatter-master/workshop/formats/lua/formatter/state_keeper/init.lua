return
  function(self)
    self.states = {}
    self.position = 0
  end
