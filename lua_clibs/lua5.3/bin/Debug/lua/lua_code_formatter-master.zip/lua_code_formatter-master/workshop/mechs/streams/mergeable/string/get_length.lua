return
  function(self)
    return #self.s
  end
