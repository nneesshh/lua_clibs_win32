return
  function(self, s)
    self.line_with_text:add(s)
  end
