return
  function(self, position_offset)
    self:set_position(self:get_position() + position_offset)
  end
