return
  {
    binary_bytes = request('binary_bytes'),
    binary_units = request('binary_units'),
    frequency = request('frequency'),
    general_number = request('general_number'),
    general_time = request('general_time'),
  }
