return
  function(self)
    return
      math.max(self.max_text_width, self.line_with_text:get_text_length())
  end
