return
  function(self)
    return utf8.len(self.text) or #self.text
  end
