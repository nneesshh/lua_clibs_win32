return
  function(self)
    return self.struc
  end
