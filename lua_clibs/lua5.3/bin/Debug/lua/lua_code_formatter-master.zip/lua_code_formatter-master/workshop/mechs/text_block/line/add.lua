return
  function(self, s)
    self.text = self.text .. s
  end
