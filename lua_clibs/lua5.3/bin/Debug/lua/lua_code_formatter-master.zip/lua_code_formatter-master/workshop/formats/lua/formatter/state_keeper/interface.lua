return
  {
    states = nil,
    position = nil,
    init = request('init'),

    enter_level = request('enter_level'),
    leave_level = request('leave_level'),
    get_state = request('get_state'),
    set_state = request('set_state'),
    get_child_state = request('get_child_state'),
    set_child_state = request('set_child_state'),
  }
