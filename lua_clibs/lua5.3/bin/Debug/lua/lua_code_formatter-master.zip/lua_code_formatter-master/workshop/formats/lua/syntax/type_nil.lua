local word = request('words.word')

return
  {
    name = 'nil',
    word('nil'),
  }
