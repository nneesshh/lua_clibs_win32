return request('!.formats.lua.quote_string')
