return
  {
    input_stream = nil,
    output_stream = nil,

    on_match = request('on_match'),

    init = request('init'),
    match = request('match'),
  }
