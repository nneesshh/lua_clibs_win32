return
  function(self)
    self:set_position(self:get_position() + 1)
  end
