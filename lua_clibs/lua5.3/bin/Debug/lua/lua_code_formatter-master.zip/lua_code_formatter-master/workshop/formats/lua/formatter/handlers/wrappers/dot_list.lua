return
  function(self, node)
    return self:process_list(node, '.')
  end
