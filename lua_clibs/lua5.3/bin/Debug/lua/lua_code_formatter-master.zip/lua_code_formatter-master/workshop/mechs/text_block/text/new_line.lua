return
  function(self)
    self.num_line_feeds = self.num_line_feeds + 1
  end
