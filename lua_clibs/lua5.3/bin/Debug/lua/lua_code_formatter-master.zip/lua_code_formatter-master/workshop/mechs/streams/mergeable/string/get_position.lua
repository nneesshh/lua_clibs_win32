return
  function(self)
    return self.position
  end
