return
  function(self)
    return
      math.max(self.max_block_width, self.line_with_text:get_line_length())
  end
