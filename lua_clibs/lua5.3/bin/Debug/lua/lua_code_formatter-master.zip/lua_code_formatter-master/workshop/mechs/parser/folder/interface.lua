return
  {
    init = request('init'),
    fold = request('fold'),
    get_struc = request('get_struc'),

    struc = nil,
    is_folded = nil,
  }
