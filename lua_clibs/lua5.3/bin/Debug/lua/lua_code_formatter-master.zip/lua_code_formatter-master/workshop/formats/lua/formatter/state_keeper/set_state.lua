return
  function(self, new_state)
    self.states[self.position] = new_state
  end
