return
  function(self, ast)
    return self.table_serializer:serialize_ast(ast)
  end
