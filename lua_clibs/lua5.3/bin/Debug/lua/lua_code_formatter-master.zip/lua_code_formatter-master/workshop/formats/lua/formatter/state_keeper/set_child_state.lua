return
  function(self, new_state)
    self.states[self.position + 1] = new_state
  end
