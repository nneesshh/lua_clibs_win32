return
  function(self, node)
    self.printer:add_curline('break')
    return true
  end
