require('lcf.workshop.base')
local f = request('lcf.reformat')
f(_G.arg)
