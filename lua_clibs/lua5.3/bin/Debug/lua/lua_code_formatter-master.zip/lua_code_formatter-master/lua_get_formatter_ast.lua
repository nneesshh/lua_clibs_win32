require('lcf.workshop.base')
local f = request('lcf.get_formatter_ast')
f(_G.arg)
