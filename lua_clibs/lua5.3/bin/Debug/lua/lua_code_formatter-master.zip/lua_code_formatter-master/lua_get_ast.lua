require('lcf.workshop.base')
local f = request('lcf.get_ast')
f(_G.arg)
